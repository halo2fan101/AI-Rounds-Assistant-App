import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mic, Square } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface NoteInputProps {
  onSubmit?: (text: string, format: string) => void;
}

export function NoteInput({ onSubmit }: NoteInputProps) {
  const [text, setText] = useState("");
  const [format, setFormat] = useState("freeform");
  const [isRecording, setIsRecording] = useState(false);

  const handleSubmit = () => {
    if (onSubmit && text.trim()) {
      onSubmit(text, format);
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    console.log(isRecording ? "Recording stopped" : "Recording started");
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <h2 className="text-xl font-semibold">Patient Note</h2>
        <Tabs value={format} onValueChange={setFormat}>
          <TabsList>
            <TabsTrigger value="freeform" data-testid="tab-freeform">Freeform</TabsTrigger>
            <TabsTrigger value="soap" data-testid="tab-soap">SOAP</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Enter patient notes here..."
            className="min-h-64 resize-none"
            data-testid="textarea-note-input"
          />
          <div className="absolute bottom-3 right-3 flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {text.length} characters
            </span>
            <Button
              variant={isRecording ? "destructive" : "default"}
              size="icon"
              onClick={toggleRecording}
              data-testid="button-voice-record"
            >
              {isRecording ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
          </div>
        </div>
        {isRecording && (
          <div className="flex items-center gap-2">
            <Badge variant="destructive" className="animate-pulse">
              Recording
            </Badge>
            <span className="text-sm text-muted-foreground">Listening...</span>
          </div>
        )}
        <div className="flex justify-between items-center">
          <div className="text-xs text-muted-foreground">
            Last saved: Never
          </div>
          <Button onClick={handleSubmit} data-testid="button-submit-note">
            Summarize with AI
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
