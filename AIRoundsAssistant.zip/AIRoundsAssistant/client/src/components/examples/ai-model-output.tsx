import { AIModelOutput } from '../ai-model-output';

export default function AIModelOutputExample() {
  return (
    <AIModelOutput 
      modelName="GPT-4o" 
      output="Patient presents with acute respiratory symptoms. Key findings include elevated temperature (101.2°F), mild cough, and clear lung sounds on auscultation. Recommend symptomatic treatment and follow-up in 48 hours if symptoms persist."
      confidence={0.92}
      testId="card-ai-output"
    />
  );
}
