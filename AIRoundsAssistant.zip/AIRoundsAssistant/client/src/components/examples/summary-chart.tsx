import { SummaryChart } from '../summary-chart';

const mockData = [
  { name: 'Mon', value: 12 },
  { name: 'Tue', value: 19 },
  { name: 'Wed', value: 15 },
  { name: 'Thu', value: 22 },
  { name: 'Fri', value: 18 },
  { name: 'Sat', value: 8 },
  { name: 'Sun', value: 5 },
];

export default function SummaryChartExample() {
  return <SummaryChart title="Summaries This Week" data={mockData} testId="chart-summary" />;
}
