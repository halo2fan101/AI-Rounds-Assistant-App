import { NoteInput } from '../note-input';

export default function NoteInputExample() {
  return (
    <NoteInput onSubmit={(text, format) => console.log('Submitted:', { text, format })} />
  );
}
