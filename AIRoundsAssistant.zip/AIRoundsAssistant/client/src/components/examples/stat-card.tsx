import { StatCard } from '../stat-card';
import { FileText } from 'lucide-react';

export default function StatCardExample() {
  return (
    <StatCard 
      title="Total Summaries" 
      value={42} 
      icon={FileText}
      trend="+12% from last week"
      testId="card-stat"
    />
  );
}
