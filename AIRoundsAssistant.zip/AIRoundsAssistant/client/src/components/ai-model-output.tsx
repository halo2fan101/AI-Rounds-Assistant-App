import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useState } from "react";

interface AIModelOutputProps {
  modelName: string;
  output: string;
  confidence?: number;
  testId?: string;
}

export function AIModelOutput({ modelName, output, confidence, testId }: AIModelOutputProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card data-testid={testId}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-semibold">{modelName}</h3>
          {confidence !== undefined && (
            <Badge variant="secondary" className="text-xs">
              {Math.round(confidence * 100)}%
            </Badge>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleCopy}
          data-testid={`${testId}-copy`}
        >
          {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
        </Button>
      </CardHeader>
      <CardContent>
        <div className="text-sm leading-relaxed whitespace-pre-wrap max-h-96 overflow-y-auto">
          {output}
        </div>
      </CardContent>
    </Card>
  );
}
