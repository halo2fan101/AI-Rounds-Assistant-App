import { AIModelOutput } from "@/components/ai-model-output";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import type { Summary, AiOutput } from "@shared/schema";

interface SummaryWithOutputs {
  summary: Summary;
  outputs: AiOutput[];
}

export default function Insights() {
  const { data: summaries, isLoading } = useQuery<Summary[]>({
    queryKey: ["/api/summaries"],
  });

  const latestSummary = summaries?.[0];

  const { data: summaryData } = useQuery<SummaryWithOutputs>({
    queryKey: ["/api/summaries", latestSummary?.id],
    enabled: !!latestSummary?.id,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">AI Insights</h1>
        <p className="text-muted-foreground mt-1">
          Compare AI-generated summaries from multiple models.
        </p>
      </div>

      {isLoading ? (
        <Skeleton className="h-48" />
      ) : !latestSummary ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">
              No summaries yet. Create your first summary to see AI insights.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <div>
                <h2 className="text-lg font-semibold">
                  Summary #{latestSummary.id.slice(0, 8)}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Analyzed by {summaryData?.outputs.length || 0} AI model(s)
                </p>
              </div>
              <Badge variant="secondary">
                {new Date(latestSummary.createdAt).toLocaleDateString()}
              </Badge>
            </CardHeader>
            <CardContent className="text-sm leading-relaxed">
              <p className="text-muted-foreground">
                Original note: {latestSummary.originalNote}
              </p>
            </CardContent>
          </Card>

          {summaryData?.outputs && summaryData.outputs.length > 0 && (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {summaryData.outputs.map((output, index) => (
                <AIModelOutput
                  key={output.id}
                  modelName={output.modelName}
                  output={output.output}
                  confidence={output.confidence || undefined}
                  testId={`card-ai-output-${index}`}
                />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
