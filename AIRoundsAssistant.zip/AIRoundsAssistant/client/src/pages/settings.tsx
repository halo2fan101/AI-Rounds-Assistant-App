import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const [translateEnabled, setTranslateEnabled] = useState(false);
  const [offlineMode, setOfflineMode] = useState(true);
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated.",
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Configure your AI Rounds Assistant preferences.
        </p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general" data-testid="tab-general">General</TabsTrigger>
          <TabsTrigger value="ai" data-testid="tab-ai">AI Models</TabsTrigger>
          <TabsTrigger value="offline" data-testid="tab-offline">Offline</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold">General Settings</h2>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="translate">Google Translate Widget</Label>
                  <p className="text-sm text-muted-foreground">
                    Enable multilingual support for patient-facing content
                  </p>
                </div>
                <Switch
                  id="translate"
                  checked={translateEnabled}
                  onCheckedChange={setTranslateEnabled}
                  data-testid="switch-translate"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold">API Configuration</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="openai">OpenAI API Key</Label>
                <Input
                  id="openai"
                  type="password"
                  placeholder="sk-..."
                  data-testid="input-openai-key"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="anthropic">Anthropic API Key</Label>
                <Input
                  id="anthropic"
                  type="password"
                  placeholder="sk-ant-..."
                  data-testid="input-anthropic-key"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gemini">Google Gemini API Key</Label>
                <Input
                  id="gemini"
                  type="password"
                  placeholder="AIza..."
                  data-testid="input-gemini-key"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="offline" className="space-y-6">
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold">Offline Mode</h2>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="offline">Enable Offline Caching</Label>
                  <p className="text-sm text-muted-foreground">
                    Store data locally for offline access
                  </p>
                </div>
                <Switch
                  id="offline"
                  checked={offlineMode}
                  onCheckedChange={setOfflineMode}
                  data-testid="switch-offline"
                />
              </div>
              <div className="pt-4 border-t">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Cache Size</p>
                    <p className="text-sm text-muted-foreground">12 MB used</p>
                  </div>
                  <Button variant="outline" size="sm" data-testid="button-clear-cache">
                    Clear Cache
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={handleSave} data-testid="button-save-settings">
          Save Changes
        </Button>
      </div>
    </div>
  );
}
