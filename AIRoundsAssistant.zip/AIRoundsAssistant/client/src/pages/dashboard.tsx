import { FileText, Users, Activity, Database } from "lucide-react";
import { StatCard } from "@/components/stat-card";
import { SummaryChart } from "@/components/summary-chart";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface Stats {
  totalSummaries: number;
  patientsToday: number;
  aiInsights: number;
  cacheSize: string;
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  const mockChartData = [
    { name: 'Mon', value: 12 },
    { name: 'Tue', value: 19 },
    { name: 'Wed', value: 15 },
    { name: 'Thu', value: 22 },
    { name: 'Fri', value: 18 },
    { name: 'Sat', value: 8 },
    { name: 'Sun', value: 5 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Welcome back! Here's your overview.
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/new">
            <Button data-testid="button-new-summary">
              <FileText className="h-4 w-4 mr-2" />
              New Summary
            </Button>
          </Link>
          <Link href="/transcribe">
            <Button variant="outline" data-testid="button-start-dictation">
              Start Dictation
            </Button>
          </Link>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Summaries"
            value={stats?.totalSummaries || 0}
            icon={FileText}
            trend="+12% from last week"
            testId="card-total-summaries"
          />
          <StatCard
            title="Patients Today"
            value={stats?.patientsToday || 0}
            icon={Users}
            trend="Recent activity"
            testId="card-patients-today"
          />
          <StatCard
            title="AI Insights"
            value={stats?.aiInsights || 0}
            icon={Activity}
            trend="+8% from last week"
            testId="card-ai-insights"
          />
          <StatCard
            title="Cache Status"
            value={stats?.cacheSize || "0 MB"}
            icon={Database}
            trend="0 items syncing"
            testId="card-cache-status"
          />
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <SummaryChart
          title="Summaries This Week"
          data={mockChartData}
          testId="chart-summaries-week"
        />
        <SummaryChart
          title="AI Model Usage"
          data={mockChartData}
          testId="chart-model-usage"
        />
      </div>
    </div>
  );
}
