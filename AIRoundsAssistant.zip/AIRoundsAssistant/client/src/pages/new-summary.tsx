import { useState } from "react";
import { NoteInput } from "@/components/note-input";
import { AIModelOutput } from "@/components/ai-model-output";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import type { Summary, AiOutput } from "@shared/schema";

export default function NewSummary() {
  const { toast } = useToast();
  const [results, setResults] = useState<{ summary: Summary; outputs: AiOutput[] } | null>(null);

  const summarizeMutation = useMutation({
    mutationFn: async (data: { originalNote: string; format: string }) => {
      const response = await fetch("/api/summarize", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to summarize");
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summaries"] });
      toast({
        title: "Summary Complete",
        description: `Generated ${data.outputs.length} AI summaries`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to generate summary. Please try again.",
        variant: "destructive",
      });
      console.error("Summarization error:", error);
    },
  });

  const handleSubmit = (text: string, format: string) => {
    summarizeMutation.mutate({ originalNote: text, format });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight">New Summary</h1>
        <p className="text-muted-foreground mt-1">
          Enter or dictate patient notes for AI-powered summarization.
        </p>
      </div>

      <NoteInput onSubmit={handleSubmit} />

      {summarizeMutation.isPending && (
        <div className="text-center py-12">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
          <p className="mt-4 text-muted-foreground">Analyzing with AI models...</p>
        </div>
      )}

      {results && results.outputs.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">AI-Generated Summaries</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {results.outputs.map((output, index) => (
              <AIModelOutput
                key={output.id}
                modelName={output.modelName}
                output={output.output}
                confidence={output.confidence || undefined}
                testId={`card-ai-output-${index}`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
