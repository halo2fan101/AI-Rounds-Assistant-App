import { 
  type Summary, 
  type InsertSummary,
  type AiOutput,
  type InsertAiOutput,
  type Transcription,
  type InsertTranscription,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Summary operations
  createSummary(summary: InsertSummary): Promise<Summary>;
  getSummary(id: string): Promise<Summary | undefined>;
  getAllSummaries(): Promise<Summary[]>;
  
  // AI Output operations
  createAiOutput(output: InsertAiOutput): Promise<AiOutput>;
  getAiOutputsBySummaryId(summaryId: string): Promise<AiOutput[]>;
  
  // Transcription operations
  createTranscription(transcription: InsertTranscription): Promise<Transcription>;
  getAllTranscriptions(): Promise<Transcription[]>;
  
  // Stats
  getSummaryCount(): Promise<number>;
  getRecentSummaries(limit: number): Promise<Summary[]>;
}

export class MemStorage implements IStorage {
  private summaries: Map<string, Summary>;
  private aiOutputs: Map<string, AiOutput>;
  private transcriptions: Map<string, Transcription>;

  constructor() {
    this.summaries = new Map();
    this.aiOutputs = new Map();
    this.transcriptions = new Map();
  }

  async createSummary(insertSummary: InsertSummary): Promise<Summary> {
    const id = randomUUID();
    const summary: Summary = {
      ...insertSummary,
      format: insertSummary.format || "freeform",
      id,
      createdAt: new Date(),
    };
    this.summaries.set(id, summary);
    return summary;
  }

  async getSummary(id: string): Promise<Summary | undefined> {
    return this.summaries.get(id);
  }

  async getAllSummaries(): Promise<Summary[]> {
    return Array.from(this.summaries.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async createAiOutput(insertOutput: InsertAiOutput): Promise<AiOutput> {
    const id = randomUUID();
    const output: AiOutput = {
      ...insertOutput,
      confidence: insertOutput.confidence ?? null,
      id,
      createdAt: new Date(),
    };
    this.aiOutputs.set(id, output);
    return output;
  }

  async getAiOutputsBySummaryId(summaryId: string): Promise<AiOutput[]> {
    return Array.from(this.aiOutputs.values())
      .filter((output) => output.summaryId === summaryId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createTranscription(insertTranscription: InsertTranscription): Promise<Transcription> {
    const id = randomUUID();
    const transcription: Transcription = {
      ...insertTranscription,
      id,
      createdAt: new Date(),
    };
    this.transcriptions.set(id, transcription);
    return transcription;
  }

  async getAllTranscriptions(): Promise<Transcription[]> {
    return Array.from(this.transcriptions.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getSummaryCount(): Promise<number> {
    return this.summaries.size;
  }

  async getRecentSummaries(limit: number): Promise<Summary[]> {
    const all = await this.getAllSummaries();
    return all.slice(0, limit);
  }
}

export const storage = new MemStorage();
