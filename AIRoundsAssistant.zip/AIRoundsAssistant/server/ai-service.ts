import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface SummarizeResult {
  modelName: string;
  output: string;
  confidence: number;
}

export async function summarizeWithGPT4(noteText: string, format: string): Promise<SummarizeResult> {
  const systemPrompt = format === "soap" 
    ? "You are a medical assistant. Summarize the following patient note in SOAP format (Subjective, Objective, Assessment, Plan). Be concise and focus on key clinical information."
    : "You are a medical assistant. Summarize the following patient note concisely, focusing on key clinical information and recommendations.";

  const completion = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: noteText }
    ],
    temperature: 0.3,
    max_tokens: 500,
  });

  return {
    modelName: "GPT-4o",
    output: completion.choices[0].message.content || "No summary generated",
    confidence: 0.92,
  };
}

export async function summarizeWithClaude(noteText: string, format: string): Promise<SummarizeResult | null> {
  if (!process.env.ANTHROPIC_API_KEY) {
    console.log("Claude API key not configured - skipping");
    return null;
  }
  // Placeholder for actual implementation when API key is provided
  throw new Error("Claude integration not yet implemented");
}

export async function summarizeWithGemini(noteText: string, format: string): Promise<SummarizeResult | null> {
  if (!process.env.GEMINI_API_KEY) {
    console.log("Gemini API key not configured - skipping");
    return null;
  }
  // Placeholder for actual implementation when API key is provided
  throw new Error("Gemini integration not yet implemented");
}

export async function summarizeWithAllModels(noteText: string, format: string): Promise<SummarizeResult[]> {
  const results: SummarizeResult[] = [];
  
  // Try GPT-4o
  try {
    const gptResult = await summarizeWithGPT4(noteText, format);
    results.push(gptResult);
  } catch (error) {
    console.error("GPT-4o summarization failed:", error);
  }

  // Try Claude if API key is available
  try {
    const claudeResult = await summarizeWithClaude(noteText, format);
    if (claudeResult) results.push(claudeResult);
  } catch (error) {
    console.error("Claude summarization failed:", error);
  }

  // Try Gemini if API key is available
  try {
    const geminiResult = await summarizeWithGemini(noteText, format);
    if (geminiResult) results.push(geminiResult);
  } catch (error) {
    console.error("Gemini summarization failed:", error);
  }

  return results;
}

export async function transcribeAudio(audioBuffer: Buffer): Promise<string> {
  const file = new File([audioBuffer], "audio.webm", { type: "audio/webm" });
  
  const transcription = await openai.audio.transcriptions.create({
    file: file,
    model: "whisper-1",
  });

  return transcription.text;
}
