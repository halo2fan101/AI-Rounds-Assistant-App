import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { summarizeWithAllModels, transcribeAudio } from "./ai-service";
import { insertSummarySchema, insertTranscriptionSchema } from "@shared/schema";
import multer from "multer";

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Create a new summary with AI analysis
  app.post("/api/summarize", async (req, res) => {
    try {
      const { originalNote, format } = insertSummarySchema.parse(req.body);
      
      // Create summary record
      const summary = await storage.createSummary({ originalNote, format: format || "freeform" });
      
      // Get AI summaries from available models
      const aiResults = await summarizeWithAllModels(originalNote, format || "freeform");
      
      // Store each AI output
      const outputs = await Promise.all(
        aiResults.map((result) =>
          storage.createAiOutput({
            summaryId: summary.id,
            modelName: result.modelName,
            output: result.output,
            confidence: result.confidence,
          })
        )
      );
      
      res.json({
        summary,
        outputs,
      });
    } catch (error) {
      console.error("Summarization error:", error);
      res.status(500).json({ error: "Failed to create summary" });
    }
  });

  // Get a summary with its AI outputs
  app.get("/api/summaries/:id", async (req, res) => {
    try {
      const summary = await storage.getSummary(req.params.id);
      if (!summary) {
        return res.status(404).json({ error: "Summary not found" });
      }
      
      const outputs = await storage.getAiOutputsBySummaryId(req.params.id);
      
      res.json({
        summary,
        outputs,
      });
    } catch (error) {
      console.error("Get summary error:", error);
      res.status(500).json({ error: "Failed to get summary" });
    }
  });

  // Get all summaries
  app.get("/api/summaries", async (req, res) => {
    try {
      const summaries = await storage.getAllSummaries();
      res.json(summaries);
    } catch (error) {
      console.error("Get summaries error:", error);
      res.status(500).json({ error: "Failed to get summaries" });
    }
  });

  // Transcribe audio
  app.post("/api/transcribe", upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No audio file provided" });
      }

      const transcriptionText = await transcribeAudio(req.file.buffer);
      
      const transcription = await storage.createTranscription({
        transcription: transcriptionText,
      });
      
      res.json(transcription);
    } catch (error) {
      console.error("Transcription error:", error);
      res.status(500).json({ error: "Failed to transcribe audio" });
    }
  });

  // Get stats for dashboard
  app.get("/api/stats", async (req, res) => {
    try {
      const totalSummaries = await storage.getSummaryCount();
      const recentSummaries = await storage.getRecentSummaries(10);
      
      res.json({
        totalSummaries,
        patientsToday: recentSummaries.length, // Simplified for now
        aiInsights: totalSummaries * 3, // Assuming ~3 models per summary
        cacheSize: "12 MB", // Placeholder
      });
    } catch (error) {
      console.error("Stats error:", error);
      res.status(500).json({ error: "Failed to get stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
